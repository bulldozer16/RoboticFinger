#ifndef _ARDUINO_COM_H
#define _ARDUINO_COM_H

void push(char * state);
void touch();
void move(int pos);
void move_ce(char pos);

#endif

